#include "coin.h"
using namespace std;

coin::coin(SpriteSheet *sheet, int width, int height):Sprite(sheet,width,height){
}

void coin::draw(SDL_Renderer *renderer){
}

#include "group.h"
#include <fstream>
#include <cstdlib>
#include <string>

Group::Group(int maxSize){
    this->maxSize = maxSize;
}


void Group::dodajAsp(reversedSprite* asp){
    if(grupa.size() >= maxSize){
        cout<<"Grupa je dostigla maximalan broj elemenata"<<endl;
    } else {
        grupa.push_back(asp);
    }

}

int Group::minUbrzanje(){
    if (grupa.size() < 1){
        cout<<"Grupa je prazna"<<endl;
        return 0;
    }
    int min = grupa[0]->maxUbrzanje;
    for(reversedSprite* asp:grupa){
        if (asp->maxUbrzanje < min){
            min = asp->maxUbrzanje;
        }
    }
    return min;
}

void Group::setMaxUbrzanje(){
    int min = minUbrzanje();

    for(reversedSprite* asp:grupa){
        asp->maxUbrzanje = min;
    }
}

void Group::save(){
    ofstream myfile;
    myfile.open("save/file.txt");
    for (reversedSprite* a:grupa){
        myfile << a->spriteRect->x << "\n" << a->spriteRect->y << "\n" << a->ubrzanje <<"\n" << a->maxUbrzanje <<"\n" << a->zamor<<"\n";
    }

    myfile.close();
}

void Group::load(){
    ifstream myfile;
    myfile.open("save/file.txt");

    if(!myfile.is_open()){
        exit(EXIT_FAILURE);
    }
    for (reversedSprite* a:grupa){
        myfile >> a->spriteRect->x;
        myfile >> a->spriteRect->y;
        myfile >> a->ubrzanje;
        myfile >> a->maxUbrzanje;
        myfile >> a->zamor;

    }
}

void Group::collide(){
    bool udario = false;
    int xRazlika = 0;
    int yRazlika = 0;

    for (reversedSprite* asp:grupa){
        if (asp->spriteRect->x >= 640){
            udario = true;
            xRazlika = -1;
            break;
        } else if (asp->spriteRect->x <= 0) {
            udario = true;
            xRazlika = 1;
            break;
        }
        if (asp->spriteRect->y >= 480){
            udario = true;
            yRazlika = -1;
            break;
        } else if (asp->spriteRect->y <= 0) {
            udario = true;
            yRazlika = 1;
            break;
        }
    }

    if (udario == true){
        for(reversedSprite* asp:grupa){
            asp->spriteRect->x += xRazlika*320;
            asp->spriteRect->y += yRazlika*240;
        }
    }
}


















#include "reversedsprite.h"
#include "destroyableSprite.h"
using namespace std;

reversedSprite::reversedSprite(SpriteSheet *sheet, int width, int height, bool isDrawn):Sprite(sheet,width,height){
}

void reversedSprite::draw(SDL_Renderer *renderer) {
    if(state&LEFT) {
        sheet->drawFrame("walk_left", currentFrame, spriteRect, renderer);
    } else if(state&RIGHT) {
        sheet->drawFrame("walk_right", currentFrame, spriteRect, renderer);
    } else if(state&UP) {
        sheet->drawFrame("walk_up", currentFrame, spriteRect, renderer);
    } else if(state&DOWN) {
        sheet->drawFrame("walk_down", currentFrame, spriteRect, renderer);
    } else if(state == STOP) {
        sheet->drawFrame("walk_down", 0, spriteRect, renderer);
    }

    frameCounter++;
    if(frameCounter%frameSkip == 0) {
        currentFrame++;
        if(currentFrame >= 9) {
            currentFrame = 0;
        }
        frameCounter = 0;
    }
    if(zamor>0){
    zamor--;
    }
    cout<<"Trenutni zamor je: "<<zamor<<endl;
}

void reversedSprite::move(int dx, int dy) {
    if(ubrzanje >= maxUbrzanje-1){
        spriteRect->x += maxUbrzanje*dx;
        spriteRect->y += maxUbrzanje*dy;
        this->ubrzanje = maxUbrzanje;
    } else {
        spriteRect->x += ubrzanje*dx;
        spriteRect->y += ubrzanje*dy;
    }
    zamor+=2;


    //  Svaki frejm ga smanjujemo za jedan pa da kompenzujemo dodajemo 2 kad se kre�e
}

void reversedSprite::move() {
    if(zamor<100){
    if(state != 0) {
        if(state & 1) {
            move(1, 0);
        }
        if(state & 2) {
            move(-1, 0);
        }
        if(state & 4) {
            move(0, 1);
        }
        if(state & 8) {
            move(0, -1);
        }
        if(state &1 &&(state &4)){
            state = STOP;
        }
        if(state &1 &&(state &8)){
            state = STOP;
        }
        if(state &2 &&(state &4)){
            state = STOP;
        }
        if(state &2 &&(state &8)){
            state = STOP;
        }
    }
    }
    else{
        if(state != 0) {
        if(state & 1) {
            move(-1, 0);
        }
        if(state & 2) {
            move(1, 0);
        }
        if(state & 4) {
            move(0, -1);
        }
        if(state & 8) {
            move(0, 1);
        }
        if(state &1 &&(state &4)){
            state = STOP;
        }
        if(state &1 &&(state &8)){
            state = STOP;
        }
        if(state &2 &&(state &4)){
            state = STOP;
        }
        if(state &2 &&(state &8)){
            state = STOP;
        }
    }
}}


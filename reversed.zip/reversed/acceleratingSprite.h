#ifndef ACCELERATING_H
#define ACCELERATING_H
#include "sprite.h"

class AcceleratingSprite:public Sprite{
public:
    int ubrzanje = 1;
    int zamor = 1;
    int maxUbrzanje;

    AcceleratingSprite(SpriteSheet *sheet, int width=64, int height=64);
    void draw(SDL_Renderer *renderer);
    void move();
    void move(int dx, int dy);
};
#endif // ACCELERATING_H

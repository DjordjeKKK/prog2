#ifndef GROUP_H
#define GROUP_H
#include "reversedsprite.h"
#include <vector>


class Group {
public:
    vector<reversedSprite*>grupa;
    int maxSize;
    Group(int maxSize);
    void dodajAsp(reversedSprite* asp);

    int minUbrzanje();
    void setMaxUbrzanje();

    void load();
    void save();

    void collide();

};

#endif // GROUP_H

var class_tile =
[
    [ "Tile", "class_tile.html#a6d4751f5e4523a166c5ad6f1f76df0cf", null ],
    [ "Tile", "class_tile.html#a7380fc4242c1bd4e14df114d37293f86", null ],
    [ "~Tile", "class_tile.html#a98634abbd93fa13d0578d7103202d03d", null ],
    [ "getRect", "class_tile.html#a3ba151a9d061cd0daf2f1bb33969fa30", null ],
    [ "h", "class_tile.html#a7abc2e398538f9da21aee7d5d8da021c", null ],
    [ "w", "class_tile.html#ab5828ddbb71a1cc54e53115e8a0e04c1", null ],
    [ "x", "class_tile.html#adc9e76de96e05f40afa4e02a894b8e8c", null ],
    [ "y", "class_tile.html#adbe18ea3b9a7ade729ac46224ba975d7", null ]
];
var indexSectionsWithContent =
{
  0: "adeghlrtwxy~",
  1: "delt",
  2: "adeghlrtwxy~"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Sve",
  1: "Klase",
  2: "Funkcije"
};


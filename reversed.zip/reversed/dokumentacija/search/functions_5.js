var searchData=
[
  ['level',['Level',['../class_level.html#a6d2198200659075e411ab260f397376a',1,'Level']]]
];

#ifndef REVERSEDSPRITE_H
#define REVERSEDSPRITE_H

#include "sprite.h"
class reversedSprite:public Sprite{
public:
    int ubrzanje = 1;
    int zamor = 1;
    int maxUbrzanje;

    reversedSprite(SpriteSheet *sheet, int width=64, int height=64);
    void draw(SDL_Renderer *renderer);
    void move();
    void move(int dx, int dy);
};
#endif // REVERSEDSPRITE_H

#ifndef REVERSEDSPRITE_H
#define REVERSEDSPRITE_H

#include "sprite.h"
#include "destroyableSprite.h"
class reversedSprite:public Sprite{
public:
    bool isDrawn;
    int ubrzanje = 2;
    int zamor = 1;
    int maxUbrzanje=1;

    reversedSprite(SpriteSheet *sheet, int width=64, int height=64, bool isDrawn=true);
    void draw(SDL_Renderer *renderer);
    void move();
    void move(int dx, int dy);

};
#endif // REVERSEDSPRITE_H

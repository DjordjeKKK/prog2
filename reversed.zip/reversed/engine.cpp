#include "engine.h"
#include "reversedsprite.h"
#include "group.h"
#include "destroyableSprite.h"
#include "vector"
#include "drawable.h"


ostream& operator<<(ostream& out, const Level& l) {
    int rows = l.getLevelMatrix().size();
    int cols = 0;
    if(rows > 0) {
        cols = l.getLevelMatrix()[0].size();
    }
    out << rows << " " << cols << endl;

    for(int i = 0; i < rows; i++){
        for(int j = 0; j < cols; j++) {
            out << l.getLevelMatrix()[i][j] << " ";
        }
        out << endl;
    }

    return out;
}

Engine::Engine(string title) {
    SDL_Init(SDL_INIT_VIDEO);
    IMG_Init(IMG_INIT_PNG);
    window = SDL_CreateWindow(title.c_str(), SDL_WINDOWPOS_UNDEFINED,
                              SDL_WINDOWPOS_UNDEFINED, 640, 480, SDL_WINDOW_RESIZABLE);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
}

void Engine::addTileset(Tileset *tileset, const string &name) {
    tilesets[name] = tileset;
}

void Engine::addTileset(istream &inputStream, const string &name) {
    addTileset(new Tileset(inputStream, renderer), name);
}

void Engine::addTileset(const string &path, const string &name) {
    ifstream tilesetStream(path);
    addTileset(tilesetStream, name);
}

Tileset* Engine::getTileset(const string &name) {
    return tilesets[name];
}

void Engine::addDrawable(Drawable *drawable) {
    drawables.push_back(drawable);
}
void Engine::collision(reversedSprite *rsp, destroyableSprite *dsp){
    int i;
    if (rsp->spriteRect->x < dsp->spriteRect->x + rsp->spriteRect->w /2 &&
   rsp->spriteRect->x + rsp->spriteRect->w /2 > dsp->spriteRect->x &&
   rsp->spriteRect->y < dsp->spriteRect->y + dsp->spriteRect->h /2 &&
   rsp->spriteRect->y + rsp->spriteRect->h /2 > dsp->spriteRect->y)
    {
        if(dsp->isDrawn== true)
                {
                for(i=0; i < drawables.size(); i++){
                    if(drawables[i]==dsp){
                        drawables.erase(drawables.begin()+i);
                        cout<<"SUDAR!"<<endl;
                        dsp->isDrawn=false;
                    }
                }
    }
}
}

void Engine::run() {
    ifstream spriteSheetStream("resources/creatures/sprite_sheet.txt");
    SpriteSheet *sheet = new SpriteSheet(spriteSheetStream, renderer);

    ifstream spriteSheetStream2("resources/creatures/sprite_sheet.txt");
    SpriteSheet *sheet2 = new SpriteSheet(spriteSheetStream2, renderer);

    reversedSprite* asp = new reversedSprite(sheet);
    asp->maxUbrzanje = 1;
    asp->setFrameSkip(2);
    Player* player = new Player(asp);
    drawables.push_back(player);
    movables.push_back(player);
    eventListeners.push_back(player);

    destroyableSprite* dsp = new destroyableSprite(sheet2);
    drawables.push_back(dsp);

    destroyableSprite* dsp2 = new destroyableSprite(sheet2);
    drawables.push_back(dsp2);

    destroyableSprite* dsp3 = new destroyableSprite(sheet2);
    drawables.push_back(dsp3);


    Group grupa = Group(3);
    grupa.dodajAsp(asp);
    grupa.load();
    grupa.setMaxUbrzanje();

    int maxDelay = 1000/frameCap;
    int frameStart = 0;
    int frameEnd = 0;
    bool running = true;
    SDL_Event event;

    cout << (*dynamic_cast<Level*>(drawables[0])) << endl;

    while(running) {
        frameStart = SDL_GetTicks();

        collision(asp,dsp);
        collision(asp,dsp2);
        collision(asp,dsp3);

        while(SDL_PollEvent(&event)) {
            if(event.type == SDL_QUIT) {
                grupa.save();
                running = false;
            } else {
                for(size_t i = 0; i < eventListeners.size(); i++) {
                    eventListeners[i]->listen(event);
                }
            }
        }

        grupa.collide();

        for(size_t i = 0; i < movables.size(); i++) {
            movables[i]->move();
            grupa.setMaxUbrzanje();
        }

        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        for(size_t i = 0; i < drawables.size(); i++) {
            drawables[i]->draw(renderer);
        }

        SDL_RenderPresent(renderer);

        frameEnd = SDL_GetTicks();
        if(frameEnd - frameStart < maxDelay) {
            SDL_Delay(maxDelay - (frameEnd - frameStart));
        }
    }

}

Engine::~Engine() {
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
}

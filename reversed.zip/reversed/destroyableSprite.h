#ifndef DESTROYABLESPRITE_H
#define DESTROYABLESPRITE_H

#include "sprite.h"


class destroyableSprite : public Sprite
{
    public:
        bool isDrawn;
        destroyableSprite(SpriteSheet *sheet, int width=64, int height=64,bool isDrawn=true);
        void draw(SDL_Renderer *renderer);

};

#endif // DESTROYABLESPRITE_H

#include "destroyableSprite.h"
#include "stdlib.h"

using namespace std;

destroyableSprite::destroyableSprite(SpriteSheet *sheet, int width, int height, bool isDrawn):Sprite(sheet,width,height){
    spriteRect->x = rand() % 250 + 100;
    spriteRect->y = rand() % 250 + 100;
}

void destroyableSprite::draw(SDL_Renderer *renderer) {
 if(state&LEFT) {
        sheet->drawFrame("walk_left", currentFrame, spriteRect, renderer);
    } else if(state&RIGHT) {
        sheet->drawFrame("walk_right", currentFrame, spriteRect, renderer);
    } else if(state&UP) {
        sheet->drawFrame("walk_up", currentFrame, spriteRect, renderer);
    } else if(state&DOWN) {
        sheet->drawFrame("walk_down", currentFrame, spriteRect, renderer);
    } else if(state == STOP) {
        sheet->drawFrame("walk_down", 0, spriteRect, renderer);
    }
}

#ifndef COIN_H
#define COIN_H

#include <sprite.h>


class coin : public sprite
{
    public:
    coin(SpriteSheet *sheet, int width=32, int height=32);
    void draw(SDL_Renderer *renderer);
};

#endif // COIN_H
